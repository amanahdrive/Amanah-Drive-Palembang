AMANAH DRIVE WEBSITE

File utama: index.html
Assets: folder assets/

Cara melihat:
1. Ekstrak ZIP ini.
2. Buka index.html di browser, atau unggah folder ke hosting statis seperti Vercel/Netlify.
3. Jangan pindahkan index.html terpisah dari folder assets.

Fitur:
- Responsive untuk desktop dan mobile
- Logo dan materi promosi yang disediakan
- Paket kursus dan harga dari brosur
- Pilihan slot jadwal
- Form pendaftaran yang menyusun pesan WhatsApp
- Google Maps embed dan tautan ulasan Google Maps

Catatan:
- Rating Google yang ditampilkan adalah 5.0 dengan 38 ulasan saat penyusunan; angka dapat berubah.
- Ulasan individual diarahkan ke Google Maps dan tidak dibuat-buat.
- Pastikan harga, layanan terkait SIM, jam operasional, dan jangkauan antar-jemput dikonfirmasi sebelum dipublikasikan.
